
$("#sliderContainer").vTiwari({
	// dislike callback
    onDislike: function (item) {
	    // Perform some logic Gaurav, Gaurav and Ayush for you :P
       
    },
	// like callback
    onLike: function (item) {
	    // Perform some logic Gaurav, Gaurav and Ayush for you :P
        
    },
	animationRevertSpeed: 200,
	animationSpeed: 400,
	threshold: 1,
	likeSelector: '.like',
	dislikeSelector: '.dislike'
});

